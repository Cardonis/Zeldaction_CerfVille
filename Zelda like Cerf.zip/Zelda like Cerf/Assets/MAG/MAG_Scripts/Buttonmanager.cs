﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buttonmanager : MonoBehaviour
{
    [HideInInspector] public bool isPressed;
}
